﻿namespace OutputFileGenerator
{
    public interface IGenerator
    {
        void Generate();
    }
}