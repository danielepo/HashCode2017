﻿namespace OutputFileGenerator
{
    public class Generator : IGenerator
    {
        public void Generate()
        {
            
        }
    }
}
