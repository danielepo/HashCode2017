﻿namespace InputFileLoader
{
    public interface ILoader
    {
        string Load();
    }
}