﻿namespace InputFileLoader
{
    public class Loader : ILoader
    {
        public string Load()
        {
            return "content";
        }
    }
}
